#Shreeji Patel
#105151171


def palindrome(a):
    if a == a[::-1]:
        print('True')
    else: 
        print('False')


'''
temp1 = 'racecar'
palindrome(temp1)

temp2 = 'python'
palindrome(temp2)

temp3 = 'madam'
palindrome(temp3)

'''