#Shreeji Patel
#105151171

percent = int(input('Please enter your percentage:'))
if percent>=80:
    print('Your grade is A')
elif 80>percent>=70:
    print('Your grade is B')
elif 70>percent>=60:
    print('Your grade is C')
elif 60>percent>=50:
    print('Your grade is D')
elif 50>percent:
    print('Your grade is F')
