#Shreeji Patel
#105151171

celsius = float(input('Please enter temperature in celsius:'))
print('%.2f C = %.2f F' %(celsius,((9/5)*celsius) + 32))